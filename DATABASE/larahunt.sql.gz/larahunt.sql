-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2021 at 07:04 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `larahunt`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `btn` varchar(100) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `title`, `description`, `btn`, `image`, `status`) VALUES
(3, 'Autem quia molestiae', 'Sint et expedita eu', 'show More', '3.jpg', 1),
(4, 'Dolor mollitia magna', 'Velit exercitationem', 'Seee More', '4.jpg', 0),
(5, 'Adipisicing hic pari', 'Voluptatum in placea', 'Hire Me', '5.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `created_at` date NOT NULL,
  `image` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `description`, `created_at`, `image`, `status`) VALUES
(1, 'Microsoft Edge will now warn users about the dangers of downloading Google Chrome', 'While the operating system-level pop-ups are a small escalation in the ongoing browser wars, this kind of behavior isn\'t new. If you use Bing to search for essentially any web browser, including Chrome, Firefox, Opera, Vivaldi, or Brave, a large ad for Edge appears both above the search results and in a giant box to the right of the search results. And whenever you log into Google\'s services using Edge or any other non-Chrome browser for the first time, you\'ll get a \"helpful\" nudge about downloading and installing Chrome. But as the provider of Windows, Microsoft definitely has more opportunities to suggest using Edge, and it takes advantage of those opportunities with frustrating regularity.', '2011-12-21', '1.jpg', 1),
(2, 'The 2022 Porsche Taycan GTS first drive', 'LOS ANGELES—A few weeks ago, we sampled Porsche\'s newest 911 variant, the Carrera GTS. Automakers\' naming conventions can be impenetrable to the casual observer, so in Porsche-speak, GTS stands for \"Gran Turismo Sport.\" It\'s basically the \"have your cake and eat it\" model in the range, as it has more power and sharper handling than the standard car, but it\'s less powerful (and cheaper) than the Turbo or the more specialized GT-plus-a-number 911s.\r\n\r\nBut today, we\'ll be talking about Porche\'s Taycan, as the company has now applied the GTS treatment to the battery-electric vehicle. Anyone who has made the mistake of asking me what my favorite car is will know just how deep my feelings for the electric Porsche run, so when Porsche asked if we wanted to test a $131,400 2022 Taycan GTS on track at Willow Springs in California, it was an easy decision.', '2011-12-21', '2.jpg', 1),
(3, 'Rocket Report: Astra to launch from Florida, NASA troubleshoots SLS issue', 'announced a plan for Europe to compete more effectively with SpaceX by developing a reusable rocket on a more rapid timeline. \"For the first time Europe ... will have access to a reusable launcher,\" Le Maire said. \"In other words, we will have our SpaceX, we will have our Falcon 9. We will make up for a bad strategic choice made 10 years ago.\"\r\n\r\nAller plus vite ... The new plan calls for the large, France-based rocket firm ArianeGroup to develop a new small-lift rocket called Maïa by the year 2026. This is four years ahead of a timeline previously set by the European Space Agency for the development of a significantly larger reusable rocket. Maïa will have a lift capacity of up to 1 metric ton to low Earth orbit and be powered by a reusable Prometheus rocket engine. As Ars explains, the politics of this are complicated.', '2011-12-21', '3.jpg', 1),
(4, 'Reiciendis facilis v', 'Quis natus ea neque ', '2011-12-21', '4.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `experiences`
--

CREATE TABLE `experiences` (
  `id` int(11) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `details` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `experiences`
--

INSERT INTO `experiences` (`id`, `company_name`, `duration`, `designation`, `details`, `status`) VALUES
(1, 'Facebook', '2017-2020', 'JUNIOR UX/UIX DESIGNER', 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and de', 1),
(2, 'Apple inc.', '2012-2017', 'Senior product DESIGNER', 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and de', 1),
(3, 'Twitter', ' 2006-2012', 'Art director DESIGNER', 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and de', 1),
(4, '2016-2020', 'LinkedIn', 'Android App Developer', 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and de', 1);

-- --------------------------------------------------------

--
-- Table structure for table `logos`
--

CREATE TABLE `logos` (
  `id` int(11) NOT NULL,
  `logo` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logos`
--

INSERT INTO `logos` (`id`, `logo`, `status`) VALUES
(4, '4.png', 0),
(5, '5.png', 0),
(6, '6.png', 0),
(7, '7.png', 0),
(8, '8.jpg', 0),
(9, '9.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `menu_link` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `menu_name`, `menu_link`, `status`) VALUES
(1, 'Home', '#home', 1),
(2, 'About', '#about', 1),
(3, 'Experience', '#experience', 1),
(4, 'Projects', '#projects', 1),
(5, 'Testimonials', '#testimonials', 1);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`) VALUES
(1, 'Deacon Holt', 'fyku@mailinator.com', 'Voluptatem quam aut');

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` int(11) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `logo`, `status`) VALUES
(1, '1.png', 1),
(2, '2.png', 1),
(3, '3.png', 1),
(4, '4.png', 1),
(5, '5.png', 1),
(6, '6.png', 1),
(7, '7.png', 1),
(8, '8.png', 1),
(9, '9.png', 1),
(10, '10.png', 1),
(11, '11.png', 1),
(12, '12.png', 1),
(13, '13.png', 1),
(14, '14.png', 1),
(15, '15.png', 1),
(16, '16.png', 1),
(17, '17.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `client` varchar(100) NOT NULL,
  `completion` date NOT NULL,
  `type` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `budget` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `category`, `client`, `completion`, `type`, `author`, `budget`, `image`, `status`) VALUES
(1, 'Temporibus eius quis', 'Adipisci rem adipisi', 'Commodo expedita qui', '2000-08-26', 'Rerum molestias haru', 'In nulla explicabo ', 1000, '1.jpg', 1),
(2, 'Nisi ut maiores natu', 'Magna consequat Sin', 'Ad quae qui laudanti', '1989-02-05', 'Quos consequat Ut a', 'Necessitatibus ea an', 0, '2.jpg', 1),
(3, 'Labore numquam est e', 'Cupidatat dolorem no', 'Veniam iure ullamco', '2018-11-28', 'Explicabo A dolor e', 'Labore maxime nisi e', 0, '3.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `logo_class` varchar(100) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `logo_class`, `service_name`, `description`, `status`) VALUES
(1, 'finger-print-outline', 'Web design', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form', 0),
(2, 'logo-html5', 'HTML5', 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the', 1),
(3, 'logo-laravel', 'Laravel', 'Laravel is a web application framework with expressive, elegant syntax. We’ve already laid the foundation — freeing you to create without sweating the small things.', 1),
(4, 'logo-wordpress', 'WORDPRESS', 'WordPress is a content management system (CMS) that allows you to host and build websites. WordPress contains plugin architecture and a template system, so you can customize any website to fit your business, blog, portfolio, or online store.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int(11) NOT NULL,
  `skill_name` varchar(100) NOT NULL,
  `percentage` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `skill_name`, `percentage`, `status`) VALUES
(1, 'Digital Marketing', 40, 0),
(2, 'Graphic Design', 70, 0),
(3, 'Web Development', 70, 1),
(4, 'App Development', 70, 1),
(5, '3d animation', 65, 1);

-- --------------------------------------------------------

--
-- Table structure for table `social`
--

CREATE TABLE `social` (
  `id` int(11) NOT NULL,
  `icon_name` varchar(100) NOT NULL,
  `icon_class` varchar(100) NOT NULL,
  `social_link` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `social`
--

INSERT INTO `social` (`id`, `icon_name`, `icon_class`, `social_link`, `status`) VALUES
(1, 'Facebook', 'logo-facebook', 'https://web.facebook.com/mdsuzayethossen', 1),
(2, 'Twitter', 'logo-twitter', 'https://twitter.com/mdsuzayethossan', 1),
(3, 'Linkedin', 'logo-linkedin', 'https://www.linkedin.com/in/mdsuzayethossan/', 1),
(4, 'Instagram', 'logo-instagram', 'https://www.instagram.com/mdsuzayethossan/', 1);

-- --------------------------------------------------------

--
-- Table structure for table `submenus`
--

CREATE TABLE `submenus` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `submenu_name` varchar(100) NOT NULL,
  `submenu_link` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `submenus`
--

INSERT INTO `submenus` (`id`, `menu_id`, `submenu_name`, `submenu_link`, `status`) VALUES
(1, 4, 'PhP', '#php', 1),
(2, 4, 'Laravel', '#laravel', 1),
(3, 2, 'Visson', '#vission', 1),
(4, 2, 'Mission', '#mission', 1),
(5, 3, 'Main ', '#main', 0),
(6, 3, 'Hero', '#hero', 0);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `quiote` varchar(50) NOT NULL,
  `comments` text NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `quiote`, `comments`, `client_name`, `designation`) VALUES
(1, '\"', 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer', 'Richard', ' - Adobe sales manager'),
(2, '\"', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', 'Paul', '- CEO of Appler'),
(5, '\"', 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer', 'Mahadi Tahsan', 'Sr. Faculty'),
(6, '\"', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', 'Shohan Hossain Ean', '- Head of Department'),
(7, '\"', 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer', 'Mohammad Ullah Rocky', 'Sr. Faculty');

-- --------------------------------------------------------

--
-- Table structure for table `times`
--

CREATE TABLE `times` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `years` int(11) NOT NULL,
  `only_years` varchar(100) NOT NULL,
  `only_experience` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `times`
--

INSERT INTO `times` (`id`, `description`, `years`, `only_years`, `only_experience`) VALUES
(1, 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered ', 7, 'Years', 'of experience');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `country` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  `role` int(11) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `country`, `created_at`, `role`, `image`, `status`) VALUES
(2, 'MD SUZAYET HOSSAN', 'md.suzayet.377@gmail.com', '$2y$10$d/.XQz7fut2E.DcppUwYd.eCGSbqC3u4pbikNXct1ZK40J17MgKfO', 'Argentina', '2007-12-21', 1, '2.jpg', 0),
(3, 'MD IMTIAJ AHMED', 'mdimtiajahmedemon@gmail.com', '$2y$10$43wtHwLo7cfzqehUAcLVy..827aOOgejrDgondJkZ3eI94ppB.tEW', 'Pakistan', '2007-12-21', 2, '3.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experiences`
--
ALTER TABLE `experiences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logos`
--
ALTER TABLE `logos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social`
--
ALTER TABLE `social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submenus`
--
ALTER TABLE `submenus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `times`
--
ALTER TABLE `times`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `experiences`
--
ALTER TABLE `experiences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `logos`
--
ALTER TABLE `logos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `social`
--
ALTER TABLE `social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `submenus`
--
ALTER TABLE `submenus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `times`
--
ALTER TABLE `times`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
